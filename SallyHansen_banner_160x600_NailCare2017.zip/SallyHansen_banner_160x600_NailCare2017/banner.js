var bannerboy = bannerboy || {};
bannerboy.main = function() {

	var width = 160;
	var height = 600;
	var banner = bannerboy.createElement({perspective: 1000, id: "banner", width: width, height: height, backgroundColor: "#ffffff", overflow: "hidden", cursor: "pointer", parent: document.body});
	var main_tl;

	// adform vars
	var clickTAGvalue = dhtml.getVar('clickTAG', 'http://www.example.com');
	var landingpagetarget = dhtml.getVar('landingPageTarget', '_blank');

	var images = [
	"last_frame.jpg", 
	"txt_1.png", 
	"cta_txt.png", 
	"cta_txt_hover.png", 
	"logo.png", 
	"sprite_sheet.jpg",  
	];

	bannerboy.preloadImages(images, function() {

		/* Create elements
		================================================= */
		/* eslint-disable indent, no-unused-vars */
		
		var bottom_plate = bannerboy.createElement({backgroundColor: "#ffc1a7", left: -13, top: 146, width: 186, height: 454, parent: banner});
		var top_plate = bannerboy.createElement({backgroundColor: "#fb4b01", left: -13, top: -39, width: 209, height: 185, parent: banner});
		var behind_sprite = bannerboy.createElement({backgroundColor: "#2a2828", top: 250, width: 160, height: 231, parent: banner});
		var last_frame = bannerboy.createElement({backgroundImage: "last_frame.jpg", top: 250, parent: banner});
		var cta = bannerboy.createElement({left: 6, top: 177, width: 148, height: 24, parent: banner});
			var cta_base = bannerboy.createElement({backgroundColor: "#fb4b01", width: 148, height: 24, parent: cta});
			var cta_txt = bannerboy.createElement({backgroundImage: "cta_txt.png", left: 7, top: 8, retina: true, parent: cta});
			var cta_hover = bannerboy.createElement({width: 148, height: 24, parent: cta});
				var cta_base_hover = bannerboy.createElement({backgroundColor: "#ffffff", width: 148, height: 24, parent: cta_hover});
				var cta_txt_hover = bannerboy.createElement({backgroundImage: "cta_txt_hover.png", left: 7, top: 8, retina: true, parent: cta_hover});
		var txt_1 = bannerboy.createElement({backgroundImage: "txt_1.png", left: 6, top: 27, retina: true, parent: banner});
		var logo_container = bannerboy.createElement({left: 27, top: 531, width: 133, height: 41, parent: banner});
			var logo_plate = bannerboy.createElement({backgroundColor: "#fb4b01", width: 133, height: 41, parent: logo_container});
			var logo = bannerboy.createElement({backgroundImage: "logo.png", left: 9, top: 5, retina: true, parent: logo_container});

		var border = bannerboy.createElement({width: width, height: height, border: "1px solid #000", boxSizing: "border-box", parent: banner});
		
		/* eslint-enable indent, no-unused-vars */

		/* Create additional elements
		================================================= */

		var sprite =  bannerboy.createElement({type: "sprite", backgroundImage: "sprite_sheet.jpg", top: 250, width: 160, height: 231, frames: 43, insertAfter: behind_sprite});

		/* Adjustments
		================================================= */

		cta_hover.set({opacity: 0}); 
		last_frame.set({opacity: 0}); 

		/* Initiate
		================================================= */

		/* Animations
		================================================= */

		sprite.tl_in = new BBTimeline()
		.fromTo(sprite, 1.90, {frame: 1}, {frame: 44, ease: Linear.easeNone, onUpdate: sprite.update})
		.chain()
		.fromTo(sprite, 1.90, {frame: 1}, {frame: 44, ease: Linear.easeNone, onUpdate: sprite.update})
		.chain()
		.fromTo(sprite, 1.90, {frame: 1}, {frame: 44, ease: Linear.easeNone, onUpdate: sprite.update})
		.chain()
		.fromTo(sprite, 1.90, {frame: 1}, {frame: 44, ease: Linear.easeNone, onUpdate: sprite.update})
		.chain()
		.fromTo(sprite, 1.90, {frame: 1}, {frame: 44, ease: Linear.easeNone, onUpdate: sprite.update})
		.chain()
		.fromTo(sprite, 1.90, {frame: 1}, {frame: 44, ease: Linear.easeNone, onUpdate: sprite.update})
		.chain()
		.fromTo(sprite, 1.90, {frame: 1}, {frame: 43, ease: Linear.easeNone, onUpdate: sprite.update})

		last_frame.tl_in = new BBTimeline()
		.to(last_frame, 0.01, {opacity: 1, ease: Linear.easeNone})

		/* Main Timeline
		================================================= */

		main_tl = new BBTimeline()

		.add(sprite.tl_in)
		.chain()
		.add(last_frame.tl_in)

		scrubber(main_tl);

		/* Interactions
		================================================= */
		banner.addEventListener("mouseenter", function() {
				cta_hover.to(0.0001, {opacity: 1})
		});

		banner.addEventListener("mouseleave", function() {
				cta_hover.to(0.0001, {opacity: 0})				
		});

		banner.onclick = function() {
		    window.open(clickTAGvalue, landingpagetarget); 
		}

	    /* Helper
		================================================= */

		/* Scrubber
		================================================= */
		function scrubber(tl) {
			if (window.location.origin == "file://") {
				bannerboy.include(["../bannerboy_scrubber.min.js"], function() {
					if (bannerboy.scrubberController) bannerboy.scrubberController.create({"main timeline": tl});
				});
			}
		}
	});
};