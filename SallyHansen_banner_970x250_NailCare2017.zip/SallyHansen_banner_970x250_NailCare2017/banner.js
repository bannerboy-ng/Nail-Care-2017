var bannerboy = bannerboy || {};
bannerboy.main = function() {

	var width = 970;
	var height = 250;
	var banner = bannerboy.createElement({perspective: 1000, id: "banner", width: width, height: height, backgroundColor: "#ffffff", overflow: "hidden", cursor: "pointer", parent: document.body});
	var main_tl;

	// adform vars
	var clickTAGvalue = dhtml.getVar('clickTAG', 'http://www.example.com');
	var landingpagetarget = dhtml.getVar('landingPageTarget', '_blank');

	var images = [
		"last_frame.jpg", 
		"txt_1.png", 
		"logo.png", 
		"cta_txt.png", 
		"cta_txt_hover.png",
		"sprite_sheet.jpg"
	];

	bannerboy.preloadImages(images, function() {

		/* Create elements
		================================================= */
		/* eslint-disable indent, no-unused-vars */
		
		var bg_2 = bannerboy.createElement({backgroundColor: "#ffc1a8", left: -1, top: -175, width: 972, height: 600, parent: banner});
		var bg_1 = bannerboy.createElement({backgroundColor: "#fb4b01", left: -4, top: -3, width: 976, height: 67, parent: banner});
		var behind_sprite = bannerboy.createElement({left: 43, width: 541, height: 250, parent: banner});
		var last_frame = bannerboy.createElement({backgroundImage: "last_frame.jpg", left: 43, parent: banner});
		var txt_1 = bannerboy.createElement({backgroundImage: "txt_1.png", left: 625, top: 82, retina: true, parent: banner});
		var logo_container = bannerboy.createElement({left: 815, top: 10, width: 144, height: 46, parent: banner});
			var logo = bannerboy.createElement({backgroundImage: "logo.png", retina: true, parent: logo_container});
		var cta = bannerboy.createElement({left: 673, top: 191, width: 285, height: 44, parent: banner});
			var cta_base = bannerboy.createElement({backgroundColor: "#fb4b01", width: 285, height: 44, parent: cta});
			var cta_txt = bannerboy.createElement({backgroundImage: "cta_txt.png", left: 12, top: 13, retina: true, parent: cta});
			var cta_hover = bannerboy.createElement({width: 285, height: 44, parent: cta});
				var cta_base_hoover = bannerboy.createElement({backgroundColor: "#ffffff", width: 285, height: 44, parent: cta_hover});
				var cta_txt_hover = bannerboy.createElement({backgroundImage: "cta_txt_hover.png", left: 12, top: 13, retina: true, parent: cta_hover})




		var border = bannerboy.createElement({width: width, height: height, border: "1px solid #000", boxSizing: "border-box", parent: banner});
		
		/* eslint-enable indent, no-unused-vars */

		/* Create additional elements
		================================================= */

		var sprite =  bannerboy.createElement({type: "sprite", backgroundImage: "sprite_sheet.jpg", width: 540, height: 250, left:43, frames: 25, insertAfter: behind_sprite});

		/* Adjustments
		================================================= */

		cta_hover.set({opacity: 0}); 
		last_frame.set({opacity: 0}); 

		/* Initiate
		================================================= */

		/* Animations
		================================================= */

		sprite.tl_in = new BBTimeline()
		.fromTo(sprite, 1.9, {frame: 1}, {frame: 25, ease: Linear.easeNone, onUpdate: sprite.update})
		.chain()
		.fromTo(sprite, 1.9, {frame: 1}, {frame: 25, ease: Linear.easeNone, onUpdate: sprite.update})
		.chain()
		.fromTo(sprite, 1.9, {frame: 1}, {frame: 25, ease: Linear.easeNone, onUpdate: sprite.update})
		.chain()
		.fromTo(sprite, 1.9, {frame: 1}, {frame: 25, ease: Linear.easeNone, onUpdate: sprite.update})
		.chain()
		.fromTo(sprite, 1.9, {frame: 1}, {frame: 25, ease: Linear.easeNone, onUpdate: sprite.update})
		.chain()
		.fromTo(sprite, 1.9, {frame: 1}, {frame: 24, ease: Linear.easeNone, onUpdate: sprite.update})
		.chain()


		last_frame.tl_in = new BBTimeline()
		.to(last_frame, 0.01, {opacity: 1, ease: Linear.easeNone})

		/* Main Timeline
		================================================= */

		main_tl = new BBTimeline()

		.add(sprite.tl_in)
		.chain()
		.add(last_frame.tl_in)

		scrubber(main_tl);

		/* Interactions
		================================================= */
		banner.addEventListener("mouseenter", function() {
				cta_hover.to(0.0001, {opacity: 1})
		});

		banner.addEventListener("mouseleave", function() {
				cta_hover.to(0.0001, {opacity: 0})				
		});

		banner.onclick = function() {
		    window.open(clickTAGvalue, landingpagetarget); 
		}

	    /* Helper
		================================================= */

		/* Scrubber
		================================================= */
		function scrubber(tl) {
			if (window.location.origin == "file://") {
				bannerboy.include(["../bannerboy_scrubber.min.js"], function() {
					if (bannerboy.scrubberController) bannerboy.scrubberController.create({"main timeline": tl});
				});
			}
		}
	});
};